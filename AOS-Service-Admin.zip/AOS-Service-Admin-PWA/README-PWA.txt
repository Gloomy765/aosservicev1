============================================================
AOS SERVICE ADMIN — PROGRESSIVE WEB APP (PWA) PACKAGE
============================================================

Senarai Fail Dalam Pakej Ini:
1. index.html          -> Aplikasi utama (Admin Dashboard AOS Service)
2. manifest.json       -> Konfigurasi PWA (Nama, Ikon, Tema, Shortcuts)
3. sw.js               -> Service Worker (Sokongan Offline & Cache Pantas)
4. offline.html        -> Halaman sandaran jika sambungan internet terputus
5. icons/              -> Set ikon lengkap PWA (32px hingga 1024px, Apple Touch & Maskable)

Cara Menjalankan & Memasang PWA:
- Service Worker dan pemasangan PWA memerlukan protokol HTTPS (atau localhost).
- Muat naik kesemua fail & folder dalam ZIP ini ke mana-mana hosting percuma seperti:
  * Netlify Drop (app.netlify.com/drop)
  * Vercel (vercel.com)
  * Firebase Hosting
  * GitHub Pages
- Selepas dibuka melalui pautan HTTPS:
  * Android (Chrome): Tekan butang "Pasang App" dalam aplikasi atau menu (⋮) -> "Install App".
  * iPhone / iPad (Safari): Tekan butang "Pasang App" atau ikon Share -> "Add to Home Screen".
  * PC / Laptop (Chrome / Edge): Klik ikon Install pada bar alamat URL.
